// plugin
import './plugins/camelCaseMotion';
import './plugins/easymotion/easymotion.cmd';
import './plugins/easymotion/registerMoveActions';
import './plugins/sneak';
import './plugins/replaceWithRegister';
import './plugins/surround';
import './plugins/targets/targets';
